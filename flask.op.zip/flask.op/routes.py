from flask import render_template,redirect,jsonify,request,session,url_for
from flask import Flask
from params_req import BaseResponseParams
from datetime import datetime
import time,os

app = Flask(
    __name__,
)

app.secret_key = "a new web"
app.jinja_env.auto_reload = True

@app.route("/",methods=["GET"])
def home():
    requests = BaseResponseParams(request)

    params = {
        "requests":requests,
    }

    return render_template("clac.html",**params)

@app.route("/upload_content",methods=["POST"])
def upload_content():
    requests = BaseResponseParams(request)

    file = request.files.get("file")
    save_path = "./upload"
    os.makedirs(save_path, exist_ok=True)
    file.save(os.path.join(save_path, str((time.time() * 1000)) + ".csv"))

    return jsonify({
        "code" : 200,
        "data" : {
            "res": 13123123123123,
        }
    })

if __name__ == "__main__":
    app.run(debug=True)