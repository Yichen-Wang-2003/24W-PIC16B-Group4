import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor
import sqlite3
import math

# Read in the data from the database

conn = sqlite3.connect(r'D:\Programmer\ProgrammerPersionWrok\Python\192_flask_csv_\Archive\tables.db')

# show database content
cursor = conn.cursor()
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
print(cursor.fetchall())
# Extract two tables from it and store them in two pd df
ds = pd.read_sql_query("SELECT * from df_2023_h1_feature", conn)
target = pd.read_sql_query("SELECT * from df_2023_h1_target", conn)

ds_new = ds.copy()
ds

# we first standardize two cols
from sklearn.preprocessing import StandardScaler
import warnings
with warnings.catch_warnings():
# ignore all caught warnings
    warnings.filterwarnings("ignore")
    scaler = StandardScaler()
    tbd = ['[QUOTE_UNIXTIME]', '[EXPIRE_UNIX]']
    ds_new[tbd] = scaler.fit_transform(ds[tbd])

ds
target

# Merge target and ds directly, as they match and have the same length
ds_new = pd.concat([ds_new, target], axis=1)

ds_new.columns


# Add new cols for the target, namely -rt and price diff
ds_new['-rt'] = -0.04*(ds['[EXPIRE_UNIX]'] - ds['[QUOTE_UNIXTIME]'])/(3600*365*24)
ds_new['price_diff'] = ds_new['[STRIKE]'] - ds_new['discounted_price']
ds_new['-rt'] = pd.to_numeric(ds_new['-rt'])
ds_new['exp(-rt)'] = ds_new['-rt'].apply(lambda x: math.exp(x))
ds_new = ds_new.loc[:, ~ds_new.columns.str.contains('^Unnamed')]
ds = ds.loc[:, ~ds.columns.str.contains('^Unnamed')]


features = ds_new[['[QUOTE_UNIXTIME]', '[EXPIRE_UNIX]', '[STRIKE]', '[UNDERLYING_LAST]', '[C_DELTA]', '[C_GAMMA]', '[C_VEGA]',
       '[C_THETA]', '[C_RHO]', '[C_IV]', '[C_VOLUME]','[C_BID]', '[C_ASK]', '[P_DELTA]', '[P_GAMMA]', '[P_VEGA]', '[P_THETA]',
       '[P_RHO]', '[P_IV]', '[P_VOLUME]', '[P_BID]', '[P_ASK]']].values
target_1= ds_new['price_diff']*ds_new['exp(-rt)']
seq_length = 10 # Number of days to look back


# Sequence creation
def seq(data, seq_length):
    xseq = []
    yseq = []
    for i in range(len(data)-seq_length-1):
        x = data[i:(i+seq_length)]
        y = target_1[i+seq_length]
        xseq.append(x)
        yseq.append(y)
    return np.array(xseq), np.array(yseq)
X,y = seq(features, seq_length)


target_1_seq = np.array(target_1)

X_train = X[:210000]
y_train = y[:210000]

X_val = X[210000:255000]
y_val = y[210000:255000]

X_test = X[255000:]
y_test = y[255000:]

y_train = y_train.reshape(-1, 1)
y_val = y_val.reshape(-1, 1)
y_test = y_test.reshape(-1, 1)
X_train = X_train.astype(float)  # Convert to float if it's a numpy array
X_train = torch.tensor(X_train, dtype=torch.float)  # Then convert to a PyTorch tensor
y_train = torch.tensor(y_train, dtype=torch.float)
X_val = torch.tensor(X_val, dtype=torch.float)
y_val = torch.tensor(y_val, dtype=torch.float)
X_test = torch.tensor(X_test, dtype=torch.float)
y_test = torch.tensor(y_test, dtype=torch.float)

print(X_train.shape, y_train.shape, X_val.shape, y_val.shape, X_test.shape, y_test.shape)


class RNN_2(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size=1, dropout=0.5):
        super(RNN_2, self).__init__()
        # hidden layer size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout)
        self.fc = nn.Linear(hidden_size, output_size)
        self.fc1 = nn.Linear(output_size, 1)
        self.relu = nn.ReLU()

    def forward(self, x):
        test_h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size)
        # print(f"test_h0 has shape,{test_h0.shape}")  # Should work without error and print the shape)
        # initialize hidden state with zeros
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size)
        # initialize cell state with zeros
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size)
        output, _ = self.lstm(x, (h0.detach(), c0.detach()))
        output = self.fc(output[:, -1, :])
        output = self.relu(output)
        output = self.fc1(output)
        return output


# Model instantiation
model = RNN_2(input_size=X_train.shape[2], hidden_size=50, num_layers=3)

criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=1e-1, weight_decay=1e-4)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# For early stopping
patience = 20
optimal_val_loss = np.inf
current_patience = 0
# Training phase
num_epochs = 100
for epoch in range(num_epochs):
    model.train()
    optimizer.zero_grad()
    outputs = model(X_train)
    assert outputs.shape == y_train.shape, f"Shape mismatch: outputs {outputs.shape}, target {y_train.shape}"
    loss = criterion(outputs, y_train)

    # Backward and optimize
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    # Validation phase
    model.eval()
    with torch.no_grad():
        val_outputs = model(X_val)
        val_loss = criterion(val_outputs, y_val)
        # Early stopping
        if val_loss < optimal_val_loss:
            optimal_val_loss = val_loss
            torch.save(model.state_dict(), 'best_model.pt')
            current_patience = 0
        else:
            current_patience += 1
            if current_patience == patience:
                print(f'Early stopping at epoch {epoch + 1}')
                # load best model
                model.load_state_dict(torch.load('best_model.pt'))
                break

    if (epoch + 1) % 10 == 0:
        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item()}, Val Loss: {val_loss.item()}')



model.eval()
with torch.no_grad():
    predictions = model(X_test)
    test_loss = criterion(predictions, y_test)
    print(f'Test Loss: {test_loss.item()}')
criterion = torch.nn.MSELoss()
mse_loss = criterion(predictions, y_test)
print(f"MSE Loss: {mse_loss.item()}")
# R2 score
from sklearn.metrics import r2_score
r2 = r2_score(y_test, predictions)
print(f"R2 Score: {r2}")

# Visualize the results with different colors
import matplotlib.pyplot as plt
plt.figure(figsize=(14,7))
# plt.plot(y_test, label = "True", color = 'blue')
plt.plot(predictions, label='Predicted',color = 'red')
plt.plot(y_test, label = "True", color = 'blue')
plt.legend()
plt.title('Test Set Predictions')























