def run_method(csv_path):
    return "img.png"